mkdir build
cd build
cmake ..
make
./algo_hw2