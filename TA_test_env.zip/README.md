
Judge homework 2 of algorithm.